import { heartbeat, pendingJobs, claimJob, startJob, completeJob, failJob } from './api.js';
import { getConfig, saveConfig, extensionId } from './storage.js';

const EXT_VERSION = '0.1.0';
const STORAGE_TAB_KEY  = 'lf_auto_tab_id';
const STORAGE_WIN_KEY  = 'lf_auto_win_id';

// ── Dedicated invisible automation window + tab ───────────────────────────────
// We create ONE minimized Chrome window that never appears in the user's
// main window tab bar. The service worker may restart (MV3), so we persist
// the tab/window IDs in chrome.storage.local and reuse them across restarts.

async function getSavedIds() {
  const data = await chrome.storage.local.get([STORAGE_TAB_KEY, STORAGE_WIN_KEY]);
  return { tabId: data[STORAGE_TAB_KEY] || null, winId: data[STORAGE_WIN_KEY] || null };
}

async function saveIds(tabId, winId) {
  await chrome.storage.local.set({ [STORAGE_TAB_KEY]: tabId, [STORAGE_WIN_KEY]: winId });
}

async function clearIds() {
  await chrome.storage.local.remove([STORAGE_TAB_KEY, STORAGE_WIN_KEY]);
}

async function isTabAlive(tabId) {
  if (!tabId) return false;
  try { await chrome.tabs.get(tabId); return true; } catch { return false; }
}

async function getAutomationTab(targetUrl) {
  const { tabId, winId } = await getSavedIds();

  // Reuse existing tab if still alive
  if (await isTabAlive(tabId)) {
    const tab = await chrome.tabs.get(tabId);
    const dest = targetUrl || 'https://www.linkedin.com/feed/';
    if (!tab.url?.startsWith(dest)) {
      await chrome.tabs.update(tabId, { url: dest });
    }
    return await chrome.tabs.get(tabId);
  }

  // Create a new minimized window — tabs inside are invisible in the main Chrome window
  const dest = targetUrl || 'https://www.linkedin.com/feed/';
  const win = await chrome.windows.create({
    url: dest,
    state: 'minimized',   // ← window is minimized, not visible in taskbar during use
    focused: false,
    type: 'normal',
  });
  const newTab = win.tabs[0];
  await saveIds(newTab.id, win.id);
  return newTab;
}

async function navigateAutomationTab(url) {
  const tab = await getAutomationTab(url);
  const dest = url || 'https://www.linkedin.com/feed/';
  if (!tab.url?.startsWith(dest)) {
    await chrome.tabs.update(tab.id, { url: dest });
    return await chrome.tabs.get(tab.id);
  }
  return tab;
}

async function waitForTab(tabId) {
  for (let i = 0; i < 60; i++) {
    try {
      const t = await chrome.tabs.get(tabId);
      if (t.status === 'complete') return true;
    } catch { return false; }
    await new Promise(r => setTimeout(r, 500));
  }
  return false;
}

async function contentAction(url, type, payload = {}) {
  const tab = await navigateAutomationTab(url);
  const ready = await waitForTab(tab.id);
  if (!ready) return { status: 'error', message: 'Automation tab did not load in time' };
  // Wait for LinkedIn React to finish rendering
  await new Promise(r => setTimeout(r, 1500));
  try {
    return await chrome.tabs.sendMessage(tab.id, { type, ...payload });
  } catch {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['src/content-linkedin.js'] });
    await new Promise(r => setTimeout(r, 500));
    return await chrome.tabs.sendMessage(tab.id, { type, ...payload });
  }
}

async function closeAutomationWindow() {
  const { tabId, winId } = await getSavedIds();
  if (winId) { try { await chrome.windows.remove(winId); } catch {} }
  else if (tabId) { try { await chrome.tabs.remove(tabId); } catch {} }
  await clearIds();
}

// ── Alarm setup ───────────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(async () => {
  const cfg = await getConfig();
  if (!cfg.extensionId) await saveConfig({ extensionId: extensionId() });
  chrome.alarms.create('linkedflow_tick', { periodInMinutes: 1 });
});

chrome.alarms.get('linkedflow_tick', (alarm) => {
  if (!alarm) chrome.alarms.create('linkedflow_tick', { periodInMinutes: 1 });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'linkedflow_tick') tick();
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === 'sync_now') {
    tick().then(sendResponse).catch(err => sendResponse({ ok: false, error: String(err.message || err) }));
    return true;
  }
  if (msg?.type === 'close_automation_tab') {
    closeAutomationWindow().then(() => sendResponse({ ok: true }));
    return true;
  }
});

// ── Heartbeat ─────────────────────────────────────────────────────────────────
// Uses the automation tab — never touches the user's LinkedIn tab.

async function heartbeatOnce(cfg) {
  const state = await contentAction('https://www.linkedin.com/feed/', 'account_state');
  await heartbeat({
    profile_key: cfg.profileKey,
    extension_id: cfg.extensionId,
    display_name: state.displayName || cfg.displayName || cfg.profileKey,
    current_url: state.currentUrl,
    session_active: state.loginStatus === 'logged_in',
    linkedin_login_status: state.loginStatus,
    extension_status: cfg.paused ? 'paused' : 'online',
    extension_version: EXT_VERSION,
    automation_paused: Boolean(cfg.paused),
  });
  await saveConfig({ displayName: state.displayName || cfg.displayName, lastSync: new Date().toISOString(), lastError: '' });
  return state;
}

// ── Job execution ─────────────────────────────────────────────────────────────

function taskFromJob(job) {
  const payload = job.payload || {};
  if (job.job_type === 'send_connections') {
    return { type: 'send_connection', reportType: 'send_connection', url: payload.linkedin_url, note: payload.note || '' };
  }
  if (job.job_type === 'check_messageability') {
    return { type: 'check_messageability', reportType: 'check_messageability', url: payload.linkedin_url, note: payload.note || '', fallback: payload.fallback || 'invitation' };
  }
  if (job.job_type === 'send_messages' || job.job_type === 'send_followups') {
    return { type: 'send_prepared_message', reportType: 'send_message', url: payload.linkedin_url, message: payload.message || '', message_type: payload.message_type || 'initial' };
  }
  if (job.job_type === 'send_prepared_message') {
    return { type: 'send_prepared_message', reportType: 'send_prepared_message', url: payload.linkedin_url, message: payload.message || '', message_type: payload.message_type || 'initial' };
  }
  if (job.job_type === 'send_prepared_inmail') {
    return { type: 'send_prepared_inmail', reportType: 'send_prepared_inmail', url: payload.linkedin_url, subject: payload.subject || '', message: payload.message || '', message_type: 'inmail' };
  }
  if (job.job_type === 'visit_profile') {
    return { type: 'visit_profile', reportType: 'visit_profile', url: payload.linkedin_url };
  }
  if (job.job_type === 'follow_profile') {
    return { type: 'follow_profile', reportType: 'follow_profile', url: payload.linkedin_url };
  }
  if (job.job_type === 'endorse_profile') {
    return { type: 'endorse_profile', reportType: 'endorse_profile', url: payload.linkedin_url, skill: payload.skill || '' };
  }
  if (job.job_type === 'check_reply' || job.job_type === 'wait_reply') {
    return { type: 'check_reply', reportType: 'check_reply', url: payload.linkedin_url };
  }
  if (job.job_type === 'check_connection_status' || job.job_type === 'wait_acceptance') {
    return { type: 'check_connection_status', reportType: 'check_connection_status', url: payload.linkedin_url };
  }
  if (job.job_type === 'send_inmail') {
    return { type: 'send_prepared_inmail', reportType: 'send_inmail', url: payload.linkedin_url, subject: payload.subject || '', message: payload.message || '', message_type: 'inmail' };
  }
  return { type: job.job_type, reportType: job.job_type, url: payload.linkedin_url };
}

async function runJob(job, cfg) {
  const task = taskFromJob(job);
  await saveConfig({ currentJob: `${job.job_type} ${job.id}` });
  await claimJob(job.id, cfg.profileKey);
  await startJob(job.id);
  let result;
  {
    result = await contentAction(task.url, task.type, task);
    // Inline "auto-send invitation when not messageable" fallback — ONLY for
    // legacy template-engine jobs. Visual Flow Builder campaigns identify
    // their jobs via payload.flow_node_id and define their OWN explicit
    // 'not_messageable' branch on the canvas (e.g. routing to a dedicated
    // "Send Connection Request" node). If we fired this inline fallback for
    // flow jobs too, the backend would receive a remapped 'invitation_sent'
    // status that doesn't match any of the check-node's drawn edge conditions
    // ('inmail_available' / 'message_available' / 'not_messageable') NOR the
    // generic 'default' condition (no such edge exists on this node), causing
    // the graph-walker to fall through to the first-declared edge — sending a
    // duplicate/incorrect action (e.g. an InMail) on top of the invitation we
    // just sent here. Flow campaigns must always see the raw status so the
    // user's own drawn branch decides what happens next.
    const isFlowJob = Boolean(job.payload?.flow_node_id);
    if (task.type === 'check_messageability' && result.status === 'not_messageable' && task.fallback === 'invitation' && !isFlowJob) {
      result = await contentAction(task.url, 'send_connection', { note: task.note || '' });
      result.status = result.status === 'sent' ? 'invitation_sent' : result.status;
    }
  }
  const final = {
    task_type: task.reportType || task.type,
    status: result.status || 'failed_with_reason',
    message: result.message || '',
    prospect_id: job.prospect_id,
    message_type: task.message_type,
  };
  if (['error', 'failed_with_reason', 'session_expired', 'restricted', 'limit_reached', 'cannot_connect'].includes(final.status)) {
    await failJob(job.id, final.message || final.status, final);
  } else {
    await completeJob(job.id, final);
  }
  await saveConfig({ currentJob: '', lastSync: new Date().toISOString(), lastError: '' });
}

// ── Main tick ─────────────────────────────────────────────────────────────────

export async function tick() {
  const cfg = await getConfig();
  if (!cfg.paired || !cfg.profileKey || cfg.paused) return { ok: true, skipped: true };
  try {
    await heartbeatOnce(cfg);
    const data = await pendingJobs(cfg.profileKey);
    const job = (data.jobs || [])[0];
    if (job) await runJob(job, cfg);
    return { ok: true, jobs: data.jobs?.length || 0 };
  } catch (err) {
    await saveConfig({ lastError: String(err.message || err), currentJob: '' });
    return { ok: false, error: String(err.message || err) };
  }
}
